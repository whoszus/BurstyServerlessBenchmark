wsk -i action update hello-nodejs hello/hello.js
wsk -i action update hash-nodejs hash/hash.js
wsk -i action update md5-nodejs ma5/md5.js
wsk -i action update sort-nodejs sort/sort.js