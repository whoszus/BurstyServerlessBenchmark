wsk -i action update hello-go hello/hello.go
wsk -i action update hash-go hash/hash.go
wsk -i action update md5-go md5/md5.go
wsk -i action update sort-go sort/sort.go