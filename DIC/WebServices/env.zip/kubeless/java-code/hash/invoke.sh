kubeless function deploy hash-java --runtime java1.8 --handler Hash.foo --from-file Hash.java --dependencies pom.xml
