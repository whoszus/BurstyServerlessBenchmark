kubeless function deploy hello-java --runtime java1.8 --handler Hello.foo --from-file Hello.java --dependencies pom.xml
